/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maxsumtest;

/**
 *
 * @author ppete_000
 */
public class ExecutionTimer
{
    private double start;
    private double end;
    

    public ExecutionTimer()
    {
        reset();
    }

    public void start() {
        start = System.nanoTime() / 1000000000.0;
    }

    public void end() {
        end = System.nanoTime() / 1000000000.0;
    }

    public double duration() {
        return (end - start);
    }

    public void reset() {
        start = 0;
        end = 0;
    }

    public void print() {
        System.out.print(duration()+" ");
    }
}
