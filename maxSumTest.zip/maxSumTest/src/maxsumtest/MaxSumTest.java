            /***************************************************
             * Program Title: MaxSumTest *
             * Author: Patrick Peters *
             * Class: CSCI3320, Summer 2016 *
             * Assignment #1 *
             ****************************************************/ 
package maxsumtest;
import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author ppete_000
 */
public class MaxSumTest {
    //variables for the starting and ending index for the max sub sum methods.
    static private int s_index = 0;
    static private int e_index = 0;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //FIrst, declare the main method variables. 
       int N;
       int START = -9999;
       int END = 9999; 
       ExecutionTimer timer = new ExecutionTimer();
       
       
       //Prompt the user for input.
       Scanner sc = new Scanner(System.in);
       Random random = new Random();
       System.out.println("Please enter the size of the problem (N): ");
       N = sc.nextInt();
       int[] sequence = new int[N];
       
       //Now generate the number sequence.
       for (int i = 0; i<N; i++)
       {
           sequence[i] = randomNumberGenerator(START, END, random); 
           if (N<=50)
           {
               System.out.print(sequence[i]+", ");
           }
       }
       //Now time for Algorithm 2.
       System.out.println("\nAlgorithm 2: "); 
       timer.start();
       System.out.println("Max Sum: "+maxSubSum2(sequence));
       timer.end();
       System.out.println("Starting Index: "+s_index);
       System.out.println("Ending Index: "+e_index);
       System.out.print("Execution Time: ");
       timer.print();
       System.out.print("nano seconds. \n");
       timer.reset();
       
       //Algorithm 3
       System.out.println("\nAlgorithm 3: ");
       timer.start();
       System.out.println("Max Sum: "+maxSubSum3(sequence, 0, sequence.length - 1));
       timer.end();
       System.out.println("Execution Time: ");
       timer.print();
       System.out.print("nano seconds.\n");
       timer.reset();
       
       //Algorithm 4
       System.out.println("\nAlgorithm 4: ");
       timer.start();
       System.out.println("Max Sum: "+maxSubSum4(sequence));
       timer.end();
       System.out.println("Starting Index: "+s_index);
       System.out.println("Ending Index: "+e_index);
       System.out.println("Execution Time: ");
       timer.print();
       System.out.print(" nano seconds.");
       
       
    }
    
    
    
            /***************************************************
            * FUNCTION Random Number Generator : (randomNumberGenerator) *
            * This method generates the random numbers for our MaxSum algorithms 
            * based on the input from the user in the Main method
            * INPUT PARAMETERS : 
            * int aStart: lowest value allowed in our random number sequence.
            * int aEnd: highest value allowed in our random number sequence.
            * long numberRange: result of aEnd minus aStart. This determines 
            * the range of the random number sequence.
            * Random aRandom: Our object Random for the random number sequence
            * OUTPUT : 
            * int randomNumber: random integer for the random number sequence
            * that fits within the number range. Is assigned into the sequence[]
            * array in main method.
            ****************************************************/ 
    
    private static int randomNumberGenerator(int aStart, int aEnd, Random aRandom)
    {
        long numberRange = (long)aEnd - (long)aStart + 1;
        long fraction = (long)(numberRange * aRandom.nextDouble());
        int randomNumber = (int)(fraction + aStart);
        return randomNumber;
        
    }
    
    
    
            /***************************************************
            * FUNCTION Algorithm 2 for Max Sub Sum problem : (maxSubSum2) *
            * Quadratic maximum contiguous subsequence sum algorithm 
            * INPUT PARAMETERS : *
            * a list of all parameters and their meaning *
            * OUTPUT : *
            * the description about returning value *
            ****************************************************/ 
    private static int maxSubSum2(int[] numberSequence)
    {
        
         int maxSum = 0;
         int[] results = new int[3];

         for(int i = 0; i<numberSequence.length; i++)
         {
             int thisSum = 0;
             
             for( int j = i; j < numberSequence.length; j++ )
             {
                thisSum += numberSequence[j];
                if( thisSum > maxSum )
                 {
                     maxSum = thisSum;
                     s_index = i;
                     e_index = j;

                 }
             }

            
         }
         return maxSum;
    }
    
    
            /***************************************************
            * FUNCTION Algorithm 3 for Max Sub Sum problem : (maxSubSum3) *
            * Recursive maximum contiguous subsequence sum algorithm 
            * INPUT PARAMETERS : *
            * a list of all parameters and their meaning *
            * OUTPUT : *
            * the description about returning value *
            ****************************************************/
    
    private static int maxSubSum3( int[] numberSequence, int left, int right )
    {
        if( left==right ) //Base Case
            if( numberSequence[left] > 0 )
                return numberSequence[left];
            else 
                return 0;
        int center = ( left + right ) / 2;
        int maxLeftSum = maxSubSum3(numberSequence, left, center );
        int maxRightSum = maxSubSum3(numberSequence, center + 1, right);
        int maxLeftBorderSum = 0;
        int leftBorderSum = 0;
        for (int i = center; i>=left; i--)
        {
            leftBorderSum += numberSequence[i];
            if ( leftBorderSum > maxLeftBorderSum )
                maxLeftBorderSum = leftBorderSum;
        }
        
        int maxRightBorderSum = 0;
        int rightBorderSum = 0;
        for ( int i = center + 1; i <= right; i++ )
        {
            rightBorderSum += numberSequence[i];
            if ( rightBorderSum > maxRightBorderSum )
                maxRightBorderSum = rightBorderSum;
        }
        return max3(maxLeftSum, maxRightSum,
                     maxLeftBorderSum + maxRightBorderSum);
    }
    
            /***************************************************
            * FUNCTION max3 for recursive max sub sum  : (max3) *
            * sorts final 3 values in recursive max sub sum 
            * INPUT PARAMETERS :
            * int a: maxLeftSum value passed from the recursive 
            * max sub sum.
            * int b: maxRightSum value passed from the recursive max
            * sub sum.
            * int c: Combination of the maxLeftBorderSum and 
            * maxRightBorderSum values.
            * a list of all parameters and their meaning *
            * OUTPUT : *
            * the description about returning value *
            ****************************************************/
    private static int max3(int a, int b, int c)
    {
        return a > b ? a > c ? a : c : b > c ? b : c;
    }
    
    
    
    private static int maxSubSum4 (int[] numberSequence)
    {
        int maxSum = 0;
        int thisSum = 0;
        for (int i = 0, j = 0; j<numberSequence.length; j++ )
        {
            thisSum += numberSequence[j];
            if (thisSum > maxSum)
            {
                maxSum = thisSum;
                s_index = i;
                e_index = j;
            }
            else if (thisSum < 0)
            {
                i = j + 1;
                thisSum = 0;
            }
        }
        
        return maxSum;
    }
}


